import { Component, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ResultadoPageRoutingModule } from './resultado-routing.module';

import { ResultadoPage } from './resultado.page';
import { ResultadoinfoComponent } from '../resultadoinfo/resultadoinfo.component';
import { ComponentesModule } from '../componentes/componentes.module';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    ComponentesModule,
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild([
      {
      path:'',
      component: ResultadoPage
    }
  ])
  ],
  declarations: [ResultadoPage]
})
export class ResultadoPageModule {}
