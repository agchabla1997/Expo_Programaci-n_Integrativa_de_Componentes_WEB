import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resultadoinfo',
  templateUrl: './resultadoinfo.component.html',
  styleUrls: ['./resultadoinfo.component.scss'],
})
export class ResultadoinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
