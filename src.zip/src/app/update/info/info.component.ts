import { Component, Input, OnInit } from '@angular/core';
import { Empleado } from 'src/app/empleado.module';

@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.scss'],
})
export class InfoComponent implements OnInit {

  @Input()empleadoDeLista:Empleado;
  @Input()Indice:number;

  constructor() { }

  ngOnInit() {}

}
