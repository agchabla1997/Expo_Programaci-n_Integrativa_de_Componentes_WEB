import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResultadoinfoComponent } from '../resultadoinfo/resultadoinfo.component';
import { IonicModule } from '@ionic/angular';



@NgModule({
  declarations: [
    ResultadoinfoComponent
  ],
  imports: [
    CommonModule,
    IonicModule,
  ],
  exports:[
    ResultadoinfoComponent
  ]
})
export class ComponentesModule { }
