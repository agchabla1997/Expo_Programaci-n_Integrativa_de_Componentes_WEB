import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dato',
  templateUrl: './dato.page.html',
  styleUrls: ['./dato.page.scss'],
})
export class DatoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
