import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TabNuevoPage } from './tab-nuevo.page';

const routes: Routes = [
  {
    path: '',
    component: TabNuevoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TabNuevoPageRoutingModule {}
