import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-nuevo',
  templateUrl: './tab-nuevo.page.html',
  styleUrls: ['./tab-nuevo.page.scss'],
})
export class TabNuevoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
