import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TabNuevoPageRoutingModule } from './tab-nuevo-routing.module';
import { ExploreContainerComponentModule } from '../explore-container/explore-container.module';

import { TabNuevoPage } from './tab-nuevo.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TabNuevoPageRoutingModule,
    ExploreContainerComponentModule
  ],
  declarations: [TabNuevoPage]
})
export class TabNuevoPageModule {}
